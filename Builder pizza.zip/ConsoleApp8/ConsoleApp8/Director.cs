﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    public class Director
    {
        private IPizzaBuilder _builder;

        public Director(IPizzaBuilder builder)
        {
            _builder = builder;
        }

        public void MakeMargheritaPizza()
        {
            _builder.BuildDough("Thin");
            _builder.BuildSauce("Tomato");
            _builder.BuildTopping("Mozzarella");
            _builder.BuildTopping("Basil");
        }

       
    }
}
