﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    public class PizzaBuilder : IPizzaBuilder
    {
        private Pizza _pizza;

        public PizzaBuilder()
        {
            this.Reset();
        }

        public void Reset()
        {
            _pizza = new Pizza();
        }

        public void BuildDough(string dough)
        {
            _pizza.Dough = dough;
        }

        public void BuildSauce(string sauce)
        {
            _pizza.Sauce = sauce;
        }

        public void BuildTopping(string topping)
        {
            _pizza.Toppings.Add(topping);
        }

        public Pizza GetPizza()
        {
            Pizza result = _pizza;
            this.Reset(); 
            return result;
        }
    }
}
