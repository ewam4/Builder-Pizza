﻿using System;

namespace ConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            var builder = new PizzaBuilder();
            var director = new Director(builder);


            director.MakeMargheritaPizza();
            var pizza = builder.GetPizza();
            Console.WriteLine(pizza);

       
            builder.BuildDough("Thick");
            builder.BuildSauce("Barbecue");
            builder.BuildTopping("Chicken");
            builder.BuildTopping("Onion");
            builder.BuildTopping("Corn");
            pizza = builder.GetPizza();
            Console.WriteLine(pizza);
        }
    }
}
